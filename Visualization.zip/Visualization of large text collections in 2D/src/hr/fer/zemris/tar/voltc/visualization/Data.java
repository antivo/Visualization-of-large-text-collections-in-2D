package hr.fer.zemris.tar.voltc.visualization;


import java.util.List;

public class Data {
	private int id;
	private int clazz;
	private List<Double> dim;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getClazz() {
		return clazz;
	}
	public void setClazz(int clazz) {
		this.clazz = clazz;
	}
	public List<Double> getDim() {
		return dim;
	}
	public void setDim(List<Double> dim) {
		this.dim = dim;
	}
	@Override
	public String toString() {
		return "Data [id=" + id + ", clazz=" + clazz + ", dim=" + dim + "]";
	}
	
	
}
