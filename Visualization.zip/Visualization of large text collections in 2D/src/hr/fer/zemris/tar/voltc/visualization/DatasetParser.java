package hr.fer.zemris.tar.voltc.visualization;


import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class DatasetParser {
	private final static Charset ENCODING = StandardCharsets.UTF_8;
	private final Path fFilePath;
	private final Path labelsPath;
	private final Scanner scanner;
	private final Scanner labelsScanner;
	private final String delimiter;
	private Scanner scannerInLine;
	private Scanner scannerLabelsInLine;
	
	public DatasetParser(String aFileName, String labels, String delimiter) throws IOException {
		fFilePath = Paths.get(aFileName);
		labelsPath = Paths.get(labels);
		scanner =  new Scanner(fFilePath, ENCODING.name());
		labelsScanner =  new Scanner(labelsPath, ENCODING.name());
		this.delimiter = delimiter;
	}
	
	private Map<Integer, Integer> collect() {
		Map<Integer, Integer> collection = new HashMap<Integer, Integer>();
		
		int counter = 0;
		List<String> line = getNextLabelLineEntry();
		while(null != line) {
			++counter;
			int classId = Integer.parseInt(line.get(0));
			collection.put(counter, classId);
			
			line = getNextLabelLineEntry();
		}
		
		return collection;
	}
	
	public Dataset parse() {
		Map<Integer, Integer> documentGroupLabels = collect();
		
		Dataset collection = new Dataset();
		List<String> line = getNextLineEntry();

		while(null != line) {
			int id = Integer.parseInt(line.get(0));
			int classID = documentGroupLabels.get(id);
			List<Double> dims = new ArrayList<Double>();
			for(int i = 1; i < line.size(); ++i) {
				dims.add(Double.parseDouble(line.get(i)));
			}
			Data d = new Data();
			d.setId(id);
			d.setClazz(classID);
			d.setDim(dims);
			collection.add(d);
			line = getNextLineEntry();
		}
		
		return collection;
	}
	
	public List<String> getNextLineEntry() {
		List<String> result = null;
		if(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			result = processLine(line);
		}
		return result;
	}

	private List<String> processLine(String aLine){
		List<String> result = null;
		scannerInLine = new Scanner(aLine);
	    scannerInLine.useDelimiter(delimiter);
	    if (scannerInLine.hasNext()){
	    	result = new ArrayList<String>();
	    	do {
	    		String newEntry = scannerInLine.next();
	    		result.add(newEntry);
	    	} while(scannerInLine.hasNext());
	    }
	    return result;
	}
	
	private List<String> processLineLabels(String aLine){
		List<String> result = null;
		scannerLabelsInLine = new Scanner(aLine);
	    scannerLabelsInLine.useDelimiter(delimiter);
	    if (scannerLabelsInLine.hasNext()){
	    	result = new ArrayList<String>();
	    	do {
	    		String newEntry = scannerLabelsInLine.next();
	    		result.add(newEntry);
	    	} while(scannerLabelsInLine.hasNext());
	    }
	    return result;
	}
	
	public List<String> getNextLabelLineEntry() {
		List<String> result = null;
		if(labelsScanner.hasNextLine()) {
			String line = labelsScanner.nextLine();
			result = processLineLabels(line);
		}
		return result;
	}
}

