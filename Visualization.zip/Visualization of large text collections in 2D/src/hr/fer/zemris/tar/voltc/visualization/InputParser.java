package hr.fer.zemris.tar.voltc.visualization;


public class InputParser {
	public static double[][] inputFromFile(String inputPath) {
		return null;
	}
	
	public static ClassDictionary dictionaryFromFile(String classesPath) {
		return null;
	}
}
