package hr.fer.zemris.tar.voltc.visualization;


import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClassesParser {
	private final static Charset ENCODING = StandardCharsets.UTF_8;
	private final Path fFilePath;
	private final Scanner scanner;
	private final String delimiter;
	private Scanner scannerInLine;
	
	public ClassesParser(String aFileName, String delimiter) throws IOException {
		fFilePath = Paths.get(aFileName);
		scanner =  new Scanner(fFilePath, ENCODING.name());
		this.delimiter = delimiter;
	}
	
	public ClassDictionary parse() {
		ClassDictionary collection = new ClassDictionary();
		List<String> line = getNextLineEntry();
		while(null != line) {
			String groupString = line.get(0);
			String idString = line.get(1);
			//System.out.println(groupString + " " + idString);
			collection.putClass(Integer.parseInt(idString), groupString);
			line = getNextLineEntry();
		}
		
		return collection;
	}
	
	public List<String> getNextLineEntry() {
		List<String> result = null;
		if(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			result = processLine(line);
		}
		return result;
	}

	private List<String> processLine(String aLine){
		List<String> result = null;
		scannerInLine = new Scanner(aLine);
	    scannerInLine.useDelimiter(delimiter);
	    if (scannerInLine.hasNext()){
	    	result = new ArrayList<String>();
	    	do {
	    		String newEntry = scannerInLine.next();
	    		result.add(newEntry);
	    	} while(scannerInLine.hasNext());
	    }
	    return result;
	}
}

