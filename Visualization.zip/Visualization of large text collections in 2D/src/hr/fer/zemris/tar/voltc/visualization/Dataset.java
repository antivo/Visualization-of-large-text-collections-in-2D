package hr.fer.zemris.tar.voltc.visualization;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Dataset implements Iterable<Data> {
	List<Data> dataset = new ArrayList<Data>();

	@Override
	public Iterator<Data> iterator() {
		return dataset.iterator();
	}
	
	public void add(Data d) {
		dataset.add(d);
	}
	
	public int getSize() {
		return dataset.size();
	}
	
}
