package hr.fer.zemris.tar.voltc.visualization;
import java.awt.Desktop;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JPopupMenu;

import prefuse.controls.ControlAdapter;
import prefuse.controls.Control;
import prefuse.visual.tuple.TableVisualItem;
import prefuse.visual.VisualItem;
public class FinalControlListener extends ControlAdapter implements Control {
	private final String rootDirectory;

	public FinalControlListener(String rootDirectory) {
		super();
		
		File inputFile = new java.io.File(rootDirectory);
		if(inputFile.exists()) {
			this.rootDirectory = rootDirectory;
		} else {
			this.rootDirectory = null;
		}
	}

	public void itemClicked(VisualItem item, MouseEvent e) {
		if(null == rootDirectory) {
			JPopupMenu jpub = new JPopupMenu();
			jpub.add("root directory not present or invalid");
			jpub.show(e.getComponent(),(int) item.getX(), (int) item.getY());
			return;
		}
		
		if(item instanceof TableVisualItem) {
			String fineClass = ((TableVisualItem) item).getString("FineClass");
			Integer document = (Integer) item.get("Document");

			try {
				File inputFile = new java.io.File(rootDirectory + "/" + fineClass + "/" + document);
				System.out.println(rootDirectory + "/" + fineClass + "/" + document);
				Desktop.getDesktop().open(inputFile);
			} catch (Exception e1) {
				JPopupMenu jpub = new JPopupMenu();
				jpub.add("in the given root directory " + rootDirectory + " there is no document " + document + " with label " + fineClass);
				jpub.show(e.getComponent(),(int) item.getX(), (int) item.getY());
			}
		}
	}
}