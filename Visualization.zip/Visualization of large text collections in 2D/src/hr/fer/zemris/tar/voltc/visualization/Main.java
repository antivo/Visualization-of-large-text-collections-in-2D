package hr.fer.zemris.tar.voltc.visualization;
import java.awt.Color;
import java.awt.Insets;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.Rectangle2D;
import java.io.PrintStream;
import java.text.NumberFormat;
import java.util.List;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JFrame;

import prefuse.Constants;
import prefuse.Display;
import prefuse.Visualization;
import prefuse.action.ActionList;
import prefuse.action.RepaintAction;
import prefuse.action.assignment.DataColorAction;
import prefuse.action.assignment.DataShapeAction;
import prefuse.action.layout.AxisLabelLayout;
import prefuse.action.layout.AxisLayout;
import prefuse.controls.PanControl;
import prefuse.controls.ToolTipControl;
import prefuse.controls.ZoomControl;
import prefuse.controls.ZoomToFitControl;
import prefuse.data.Table;
import prefuse.render.AbstractShapeRenderer;
import prefuse.render.AxisRenderer;
import prefuse.render.Renderer;
import prefuse.render.RendererFactory;
import prefuse.render.ShapeRenderer;
import prefuse.util.ColorLib;
import prefuse.visual.VisualItem;
import prefuse.visual.VisualTable;
import prefuse.visual.expression.VisiblePredicate;
import prefuse.visual.sort.ItemSorter;
import prefuse.data.query.NumberRangeModel;

public class Main {
	private static Table data;
	private static Visualization vis;
	private static Display d;
	
	private static final Rectangle2D boundsData = new Rectangle2D.Double();
	private static final Rectangle2D boundsLabelsX = new Rectangle2D.Double();
	private static final Rectangle2D boundsLabelsY = new Rectangle2D.Double();
	
	private static double minX = Integer.MAX_VALUE;
	private static double maxX = Integer.MIN_VALUE;
	private static double minY = Integer.MAX_VALUE;
	private static double maxY = Integer.MIN_VALUE;
	
    public static void main(String[] args) {
    	
       	String inputPath = args[0];
       	String lablesPath = args[1];
    	String classPath = args[2];
    	String coarseString = args[3];
    	String rootDirectory = args[4];
    	
    	boolean coarse = Boolean.parseBoolean(coarseString);
    	
    	try {
	    	ClassesParser cp = new ClassesParser(classPath, " ");
	    	ClassDictionary cd = cp.parse();
	    	
	    	DatasetParser dp = new DatasetParser(inputPath, lablesPath, " ");
	    	Dataset ds = dp.parse();
	    	PrintStream oldOut = System.out;
	    	//System.setOut(null);
	    	setUpData(cd, ds);
			setUpVisualization();
			setUpRenderers();
			setUpActions(cd, coarse);
			setUpDisplay(coarse, rootDirectory);
			System.setOut(oldOut);
	        // launch the visualization -------------------------------------
	        // Create a new window to hold the visualization.  
	        JFrame frame = new JFrame("Visualisation of large text collections in 2D - Mark One");
	        // Ensure application exits when window is closed
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        
	        frame.add(d);
	        frame.pack();           
	        frame.setVisible(true); 
	        
	        // start the ActionLists that are added to the visualization
	        
	        vis.run("color");
	        vis.run("layout");
	        
    	} catch (Exception e) {
    		System.out.println(e.getMessage());
    	}
	}
     
    public static void setUpData(ClassDictionary cd, Dataset ds) {	
    	data = new Table();
    	data.addColumn("Document", int.class);
    	data.addColumn("FineClass", String.class);
    	data.addColumn("CoarseClass", String.class);
    	data.addColumn("X", double.class);
    	data.addColumn("Y", double.class);
    	
    	/*Random rand = new Random();
    	int count = 4000;
    	data.addRows(count);
    	for(int i = 0 ; i < count ; ++i) {
    		data.set(i, 0, i);
    		data.set(i, 1, cd.getFineClass(rand.nextInt(20)));
    		data.set(i, 2, cd.getFineClass(rand.nextInt(20)));
    		data.set(i, 3, (rand.nextDouble() - 0.5) * 2 * Integer.MAX_VALUE);
    		data.set(i, 4, (rand.nextDouble() - 0.5) * 2 * Integer.MAX_VALUE);
    		
    	}*/
    	
    	data.addRows(ds.getSize());
    	int row = 0;
    	for(Data d : ds) {
    		Integer document = d.getId();
    		String fineClass = cd.getFineClass(d.getClazz());
    		String coarseClass = cd.getCoarseClass(d.getClazz());
    		List<Double> dims = d.getDim();
    		Double x = dims.get(0);
    		Double y = dims.get(1);
   
    		data.set(row, 0, document);
    		data.set(row, 1, fineClass);
    		data.set(row, 2, coarseClass);
    		data.set(row, 3, x);
    		data.set(row, 4, y);
    		
    		if(x < minX) {
    			minX =  x;
    		}
    		if(x > maxX) {
    			maxX = x;
    		}
    		
    		if(y < minY) {
    			minY =  y;
    			
    		}
    		if(y > maxY) {
    			maxY = y;
    		}	
    		++row;
    	}
    }
	


    // -- 2. the visualization -----------------------------------------
	public static void setUpVisualization()
	{
		vis = new Visualization();
		
		VisualTable vt = vis.addTable("data", data);
		vt.addColumn("label", 
				"CONCAT('Document: ', Document, '; FineClass: ', FineClass, '; CoarseClass: ', CoarseClass, '; X: ', FORMAT([X],2), '; Y: ', FORMAT([Y],2))");
	}
	
    // -- 3. the renderers and renderer factory -------------------------
	public static void setUpRenderers()
	{
		vis.setRendererFactory(new RendererFactory() {
			AbstractShapeRenderer sr = new ShapeRenderer(7);
			Renderer arY = new AxisRenderer(Constants.FAR_LEFT,
					Constants.CENTER);
			Renderer arX = new AxisRenderer(Constants.CENTER,
					Constants.FAR_BOTTOM);

			public Renderer getRenderer(VisualItem item) {
				return item.isInGroup("ylab") ? arY
						: item.isInGroup("xlab") ? arX : sr;
			}
		});
	}
	
	// -- 4. the actions --------------------------------------
	public static void setUpActions(ClassDictionary cd, boolean coarse)
	{
		AxisLayout x_axis = new AxisLayout("data", "X", Constants.X_AXIS, VisiblePredicate.TRUE);
		AxisLayout y_axis = new AxisLayout("data", "Y", Constants.Y_AXIS, VisiblePredicate.TRUE);

		x_axis.setLayoutBounds(boundsData);
		y_axis.setLayoutBounds(boundsData);

		AxisLabelLayout x_labels = new AxisLabelLayout("xlab", x_axis, boundsLabelsX);
		AxisLabelLayout y_labels = new AxisLabelLayout("ylab", y_axis, boundsLabelsY);

		// define the visible range for the y axis
		//y_axis.setRangeModel(new NumberRangeModel(minY + 10, maxY + 10, minY + 10, maxY + 10));
		
		// use square root scale for y axis
		y_axis.setScale(Constants.SQRT_SCALE);
		y_labels.setScale(Constants.SQRT_SCALE);

		// use a special format for y axis labels
		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMaximumFractionDigits(1);
		nf.setMinimumFractionDigits(1);
		y_labels.setNumberFormat(nf);

		//ColorAction color = new ColorAction("data", VisualItem.STROKECOLOR, ColorLib.rgb(100, 100, 255));
		
		ActionList draw = new ActionList();
		draw.add(x_axis);
		draw.add(y_axis);
		draw.add(x_labels);
		draw.add(y_labels);
		//draw.add(color);
		
		int sizeOfCoarseGrained = cd.getCoarseGrainedClasses().size();
		if(sizeOfCoarseGrained < 8) {
			int[] palette = { Constants.SHAPE_STAR, Constants.SHAPE_ELLIPSE, Constants.SHAPE_HEXAGON, Constants.SHAPE_CROSS, Constants.SHAPE_DIAMOND, Constants.SHAPE_RECTANGLE, Constants.SHAPE_TRIANGLE_DOWN};
			DataShapeAction shape = new DataShapeAction("data", "CoarseClass", palette);
			draw.add(shape);
		}
		
		int sizeOfColorPallete = 0;
		if(coarse) {
			sizeOfColorPallete = sizeOfCoarseGrained;
		} else {
			sizeOfColorPallete = cd.getFineGrainedClasses().size();
		}
		
		int[] palette = ColorLib.getCategoryPalette(sizeOfColorPallete + 1);
		
		DataColorAction fill = null; 
		if(coarse) {
			fill = new DataColorAction("data", "CoarseClass", Constants.NOMINAL, VisualItem.FILLCOLOR, palette);
		} else {
			fill = new DataColorAction("data", "FineClass", Constants.NOMINAL, VisualItem.FILLCOLOR, palette);
		}
		draw.add(fill);
		
		
		draw.add(new RepaintAction());
		vis.putAction("draw", draw);

		ActionList update = new ActionList();
		update.add(x_axis);
		update.add(y_axis);
		update.add(x_labels);
		update.add(y_labels);
		update.add(new RepaintAction());
		vis.putAction("update", update);
		

	}
	
	private static void updateBounds(Display display) {

		int paddingLeft = 30;
		int paddingTop = 15;
		int paddingRight = 30;
		int paddingBottom = 15;

		int axisWidth = 20;
		int axisHeight = 10;

		Insets i = display.getInsets();

		int left = i.left + paddingLeft;
		int top = i.top + paddingTop;
		int innerWidth = display.getWidth() - i.left - i.right - paddingLeft
				- paddingRight;
		int innerHeight = display.getHeight() - i.top - i.bottom - paddingTop
				- paddingBottom;

		boundsData.setRect(left + axisWidth, top, innerWidth - axisWidth,
				innerHeight - axisHeight);
		boundsLabelsX.setRect(left + axisWidth, top + innerHeight - axisHeight,
				innerWidth - axisWidth, axisHeight);
		boundsLabelsY.setRect(left, top, innerWidth + paddingRight, innerHeight
				- axisHeight);
	}
	
	// -- 5. the display ----------------------------------------
	public static void setUpDisplay(boolean coarse, String rootDirectory)
	{
		d = new Display(vis);
		d.setHighQuality(true);
		d.setSize(700, 450);

		if(coarse) {
			d.setBorder(BorderFactory.createTitledBorder("Coarse granied"));
		} else {
			d.setBorder(BorderFactory.createTitledBorder("Fine grained"));
		}
		// show data items in front of axis labels
		d.setItemSorter(new ItemSorter() {
			public int score(VisualItem item) {
				int score = super.score(item);
				if (item.isInGroup("data"))
					score++;
				return score;
			}
		});

		// react on window resize
		d.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				updateBounds(d);
				vis.run("update");
			}
		});

		ToolTipControl ttc = new ToolTipControl("label");
		d.addControlListener(ttc);

		d.addControlListener(new PanControl());
		d.addControlListener(new ZoomControl());
		d.addControlListener(new ZoomToFitControl());
		d.addControlListener(new FinalControlListener(rootDirectory));

		updateBounds(d);
		vis.run("draw");
		
	}    
}