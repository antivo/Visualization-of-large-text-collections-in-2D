package hr.fer.zemris.tar.voltc.visualization;


import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class ClassDictionary {
	Map<Integer, String> fineGrainedClasses = new HashMap<Integer, String>();
	Map<Integer, String> coarseGrainedClasses = new HashMap<Integer, String>();
	
	public int getSizeOfFineGrainedClasses() {
		return fineGrainedClasses.size();
	}
	
	public int getSizeOfCoarseGrainedClasses() {
		return coarseGrainedClasses.size();
	}
	
	public void putClass(Integer id, String name) {
		fineGrainedClasses.put(id, name);
		String[] clazz = name.split("\\.");
		String coarse = clazz[0];
		if(!hardcoded(clazz, id)) { 
			coarseGrainedClasses.put(id, coarse);
		}
	}
	
	private boolean hardcoded(String[] clazz, int id) {
		List<String> list = Arrays.asList(clazz);
		final String hardcoded_one = "religion";
		final String hardcoded_two = "alt";
		
		if(list.contains(hardcoded_one) || list.contains(hardcoded_two)) {
			coarseGrainedClasses.put(id, "religion");
			return true;
		}
		return false;
	}
	
	public String getFineClass(Integer id) {
		return fineGrainedClasses.get(id);
	}
	
	public String getCoarseClass(Integer id) {
		return coarseGrainedClasses.get(id);
	}
	
	public Set<String> getFineGrainedClasses() {
		return new TreeSet<String>(fineGrainedClasses.values());
	}
	
	public Set<String> getCoarseGrainedClasses() {
		return new TreeSet<String>(coarseGrainedClasses.values());
	}
}
