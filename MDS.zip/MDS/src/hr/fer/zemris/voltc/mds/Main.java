package hr.fer.zemris.voltc.mds;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import mdsj.IO;
import mdsj.MDSJ;
import hr.fer.zemris.voltc.mds.parser.Parser;
import hr.fer.zemris.voltc.similarity.Distance;

public class Main {
	private static BufferedWriter outputWriter = null;
	
	private static void write(String filename, double[][] block, int startFrom) throws IOException{
		  if(outputWriter == null) {
			  outputWriter = new BufferedWriter(new FileWriter(filename));
		  }
		  for(int i = 0; i < block[0].length; i++) {
			  String toWrite = Integer.toString(startFrom + i);
			  for(int j = 0; j < block.length; j++) {
				  if(Double.isNaN(block[j][i])) {
					  block[j][i] = 0;
				  }
				  toWrite = toWrite + " " + block[j][i];
			  }
			  
				  outputWriter.write(toWrite);
			  
			  outputWriter.newLine();
		  }
		  outputWriter.flush();  
		  //outputWriter.close();  
	}
	
	public static void main(String[] args) throws Exception {
		String inputPath = args[0];
		String dimString = args[1];
		String out = args[2];
		
		int dim = Integer.parseInt(dimString);
		
		Parser parser = new Parser(inputPath, " ", 200);
		double[][] termDocumentMatrix = parser.parse();
		int startFrom = 1;
		while(termDocumentMatrix != null) {
			Distance cs = new Distance();
			double[][] similarityMatrix = cs.transform(termDocumentMatrix);
			double[][] output = MDSJ.classicalScaling(similarityMatrix, dim);
			//IO.write(output, "out.txt");
			
			write(out, output, startFrom);
			startFrom += output[0].length;
			termDocumentMatrix = parser.parse();
		}
		
		outputWriter.close();  
	}

}
