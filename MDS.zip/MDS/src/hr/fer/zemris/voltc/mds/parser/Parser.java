package hr.fer.zemris.voltc.mds.parser;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Parser {
	private final static Charset ENCODING = StandardCharsets.UTF_8;
	private final Path fFilePath;
	private Scanner scanner;
	private final String delimiter;
	private Scanner scannerInLine;
	private boolean finished;
	
	private final int blocks;
	
	public Parser(String aFileName, String delimiter, int blocks) throws IOException {
		fFilePath = Paths.get(aFileName);
		scanner =  new Scanner(fFilePath, ENCODING.name());
		this.delimiter = delimiter;
		this.finished = false;
		this.blocks = blocks;
	}
	
	public double[][] parse() {
		if(finished) {
			return null;
		}
		
		
		List<double[]> list = new ArrayList<double[]>();
		
		int counter = 0; 
		
		List<String> line = getNextLineEntry();
		while(null != line) {
			++counter;
			double[] arr = new double[line.size() - 1];
			
			for(int i = 1; i <= arr.length; ++i) {
				double val = Double.parseDouble(line.get(i));
				arr[i - 1] = val;
			}
			list.add(arr);
			
			if(counter >= blocks) {
				break;
			}
			
			line = getNextLineEntry();
		}
		double[][] m = new double[list.size()][];
		m = list.toArray(m);
		
		if(!scanner.hasNextLine()) {
			finished = true;
		}
		
		return m;
	}
	
	public List<String> getNextLineEntry() {
		List<String> result = null;
		if(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			result = processLine(line);
		}
		return result;
	}

	private List<String> processLine(String aLine){
		List<String> result = null;
		scannerInLine = new Scanner(aLine);
	    scannerInLine.useDelimiter(delimiter);
	    if (scannerInLine.hasNext()){
	    	result = new ArrayList<String>();
	    	do {
	    		String newEntry = scannerInLine.next();
	    		result.add(newEntry);
	    	} while(scannerInLine.hasNext());
	    }
	    return result;
	}
}

