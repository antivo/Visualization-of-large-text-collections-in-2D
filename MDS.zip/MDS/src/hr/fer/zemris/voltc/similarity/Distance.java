package hr.fer.zemris.voltc.similarity;

public class Distance extends AbstractDissimilarity{

	@Override
	protected double computeDissimilarity(double[][] termDocMatrix, int rowI, int rowJ, int rowLength, double[][] disMatrix) {
		if(rowI == rowJ) {
			return 0;
		}
		
		if(disMatrix[rowJ][rowI] != 0) {
			return disMatrix[rowJ][rowI];
		}
		
		double manhattan = 0;
		for(int i = 0; i < rowLength; ++i) {
			manhattan += Math.abs(termDocMatrix[rowI][i] - termDocMatrix[rowJ][i]);
		}
		
		/*if(rowI != 0 && rowJ != 0) {
			if(disMatrix[rowI - 1][rowJ - 1] + disMatrix[rowI - 1][rowJ] <= manhattan) {
				manhattan = ;
			}
		}*/
		
		return manhattan;
	}
}

