package hr.fer.zemris.voltc.similarity;


public abstract class AbstractDissimilarity {

  public double[][] transform(double[][] termDocumentMatrix) {
	  int rows = termDocumentMatrix.length;
	  double[][] disMatrix = new double[rows][rows];
	  for(int i = 0; i < 0; ++i) {
		  for(int j = 0; j < 0; ++j) {
			  disMatrix[i][j] = 0;
		  }
	  }
	  
	  int colls = termDocumentMatrix[0].length;
	  for(int i = 0; i < rows; ++i) {
		for(int j = 0; j < rows; ++j) {
			double val = computeDissimilarity(termDocumentMatrix, i, j, colls, disMatrix);
			
			disMatrix[i][j] = val;
		}
		//System.out.println(i);
	  }
	  return disMatrix;
	  
  }

  protected abstract double computeDissimilarity(double[][] termDocMatrix, int rowI, int rowJ, int rowLength, double[][] disMatrix);
}